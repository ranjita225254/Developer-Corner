functions.php

add_action('personal_options_update', 'yoursite_save_extra_user_profile_fields');
add_action('edit_user_profile_update', 'yoursite_save_extra_user_profile_fields');

function yoursite_save_extra_user_profile_fields($user_id) {
    global $wpdb;
    $saved = false;
    if (current_user_can('edit_user', $user_id)) {
        $query = "SELECT meta_value FROM $wpdb->usermeta WHERE meta_key='mobileno' and user_id!=$user_id";
        $rows = $wpdb->get_results($query);
        foreach ($rows as $mob) {
            $mobileArray[] = $mob->meta_value;
        }
        if (in_array($_POST['mobileno'], $mobileArray)) {
                $redirect = add_query_arg('updated', false, get_edit_user_link($user_id));
                wp_redirect(add_query_arg('failed', 'no._already_exits', $redirect));
                die();
        } else {
            update_user_meta($user_id, 'mobileno', $_POST['mobileno']);
            $saved = true;
        }
        return true;
    }
}


validate.js


(function($) {

    $(document).ready(function() {
        $("#mobileno").blur(function() {
            var phoneno = /^\d{10}$/;
            if (this.value.match(phoneno))
            {
                $("input[type=submit]").prop("disabled", false);
            }
            else
            {
                $("input[type=submit]").prop("disabled", true);
                alert("Not a valid Phone Number");
            }
        })
    });

})(jQuery)

functions.php(full code)



<?php
/**
 * TwentyTen functions and definitions
 *
 * Sets up the theme and provides some helper functions. Some helper functions
 * are used in the theme as custom template tags. Others are attached to action and
 * filter hooks in WordPress to change core functionality.
 *
 * The first function, twentyten_setup(), sets up the theme by registering support
 * for various features in WordPress, such as post thumbnails, navigation menus, and the like.
 *
 * When using a child theme (see http://codex.wordpress.org/Theme_Development and
 * http://codex.wordpress.org/Child_Themes), you can override certain functions
 * (those wrapped in a function_exists() call) by defining them first in your child theme's
 * functions.php file. The child theme's functions.php file is included before the parent
 * theme's file, so the child theme functions would be used.
 *
 * Functions that are not pluggable (not wrapped in function_exists()) are instead attached
 * to a filter or action hook. The hook can be removed by using remove_action() or
 * remove_filter() and you can attach your own function to the hook.
 *
 * We can remove the parent theme's hook only after it is attached, which means we need to
 * wait until setting up the child theme:
 *
 * <code>
 * add_action( 'after_setup_theme', 'my_child_theme_setup' );
 * function my_child_theme_setup() {
 *     // We are providing our own filter for excerpt_length (or using the unfiltered value)
 *     remove_filter( 'excerpt_length', 'twentyten_excerpt_length' );
 *     ...
 * }
 * </code>
 *
 * For more information on hooks, actions, and filters, see http://codex.wordpress.org/Plugin_API.
 *
 * @package WordPress
 * @subpackage wpbootstrap
 * @since wpbootstrap 0.1
 */
/**
 * Set the content width based on the theme's design and stylesheet.
 *
 * Used to set the width of images and content. Should be equal to the width the theme
 * is designed for, generally via the style.css stylesheet.
 */
if (!isset($content_width))
    $content_width = 640;

/** Tell WordPress to run twentyten_setup() when the 'after_setup_theme' hook is run. */
add_action('after_setup_theme', 'twentyten_setup');

if (!function_exists('twentyten_setup')):

    /**
     * Sets up theme defaults and registers support for various WordPress features.
     *
     * Note that this function is hooked into the after_setup_theme hook, which runs
     * before the init hook. The init hook is too late for some features, such as indicating
     * support post thumbnails.
     *
     * To override twentyten_setup() in a child theme, add your own twentyten_setup to your child theme's
     * functions.php file.
     *
     * @uses add_theme_support() To add support for post thumbnails and automatic feed links.
     * @uses register_nav_menus() To add support for navigation menus.
     * @uses add_custom_background() To add support for a custom background.
     * @uses add_editor_style() To style the visual editor.
     * @uses load_theme_textdomain() For translation/localization support.
     * @uses add_custom_image_header() To add support for a custom header.
     * @uses register_default_headers() To register the default custom header images provided with the theme.
     * @uses set_post_thumbnail_size() To set a custom post thumbnail size.
     *
     * @since Twenty Ten 1.0
     */
    function twentyten_setup() {

        // Add default posts and comments RSS feed links to head
        add_theme_support('automatic-feed-links');

        // This theme uses wp_nav_menu() in one location.
        register_nav_menus(array(
            'primary' => __('Primary Navigation', 'twentyten'),
        ));
    }

endif;

if (!function_exists('twentyten_admin_header_style')) :

    /**
     * Styles the header image displayed on the Appearance > Header admin panel.
     *
     * Referenced via add_custom_image_header() in twentyten_setup().
     *
     * @since Twenty Ten 1.0
     */
    function twentyten_admin_header_style() {
        ?>
        <style type="text/css">
            /* Shows the same border as on front end */
            #headimg {
                border-bottom: 1px solid #000;
                border-top: 4px solid #000;
            }
            /* If NO_HEADER_TEXT is false, you would style the text with these selectors:
                    #headimg #name { }
                    #headimg #desc { }
            */
        </style>
        <?php
    }

endif;

/**
 * Makes some changes to the <title> tag, by filtering the output of wp_title().
 *
 * If we have a site description and we're viewing the home page or a blog posts
 * page (when using a static front page), then we will add the site description.
 *
 * If we're viewing a search result, then we're going to recreate the title entirely.
 * We're going to add page numbers to all titles as well, to the middle of a search
 * result title and the end of all other titles.
 *
 * The site title also gets added to all titles.
 *
 * @since Twenty Ten 1.0
 *
 * @param string $title Title generated by wp_title()
 * @param string $separator The separator passed to wp_title(). Twenty Ten uses a
 * 	vertical bar, "|", as a separator in header.php.
 * @return string The new title, ready for the <title> tag.
 */
function twentyten_filter_wp_title($title, $separator) {
    // Don't affect wp_title() calls in feeds.
    if (is_feed())
        return $title;

    // The $paged global variable contains the page number of a listing of posts.
    // The $page global variable contains the page number of a single post that is paged.
    // We'll display whichever one applies, if we're not looking at the first page.
    global $paged, $page;

    if (is_search()) {
        // If we're a search, let's start over:
        $title = sprintf(__('Search results for %s', 'twentyten'), '"' . get_search_query() . '"');
        // Add a page number if we're on page 2 or more:
        if ($paged >= 2)
            $title .= " $separator " . sprintf(__('Page %s', 'twentyten'), $paged);
        // Add the site name to the end:
        $title .= " $separator " . get_bloginfo('name', 'display');
        // We're done. Let's send the new title back to wp_title():
        return $title;
    }

    // Otherwise, let's start by adding the site name to the end:
    $title .= get_bloginfo('name', 'display');

    // If we have a site description and we're on the home/front page, add the description:
    $site_description = get_bloginfo('description', 'display');
    if ($site_description && ( is_home() || is_front_page() ))
        $title .= " $separator " . $site_description;

    // Add a page number if necessary:
    if ($paged >= 2 || $page >= 2)
        $title .= " $separator " . sprintf(__('Page %s', 'twentyten'), max($paged, $page));

    // Return the new title to wp_title():
    return $title;
}

add_filter('wp_title', 'twentyten_filter_wp_title', 10, 2);

/**
 * Get our wp_nav_menu() fallback, wp_page_menu(), to show a home link.
 *
 * To override this in a child theme, remove the filter and optionally add
 * your own function tied to the wp_page_menu_args filter hook.
 *
 * @since Twenty Ten 1.0
 */
function twentyten_page_menu_args($args) {
    $args['show_home'] = true;
    return $args;
}

add_filter('wp_page_menu_args', 'twentyten_page_menu_args');

/**
 * Sets the post excerpt length to 40 characters.
 *
 * To override this length in a child theme, remove the filter and add your own
 * function tied to the excerpt_length filter hook.
 *
 * @since Twenty Ten 1.0
 * @return int
 */
function twentyten_excerpt_length($length) {
    return 40;
}

add_filter('excerpt_length', 'twentyten_excerpt_length');

/**
 * Returns a "Continue Reading" link for excerpts
 *
 * @since Twenty Ten 1.0
 * @return string "Continue Reading" link
 */
function twentyten_continue_reading_link() {
    return ' <p><a class="btn small" href="' . get_permalink() . '">' . __('Continue reading <span class="meta-nav">&rarr;</span>', 'twentyten') . '</a></p>';
}

function my_more_link($more_link, $more_link_text) {
    return twentyten_continue_reading_link();
}

add_filter('the_content_more_link', 'my_more_link', 10, 2);

/**
 * Replaces "[...]" (appended to automatically generated excerpts) with an ellipsis and twentyten_continue_reading_link().
 *
 * To override this in a child theme, remove the filter and add your own
 * function tied to the excerpt_more filter hook.
 *
 * @since Twenty Ten 1.0
 * @return string An ellipsis
 */
function twentyten_auto_excerpt_more($more) {
    return ' &hellip;' . twentyten_continue_reading_link();
}

add_filter('excerpt_more', 'twentyten_auto_excerpt_more');

/**
 * Adds a pretty "Continue Reading" link to custom post excerpts.
 *
 * To override this link in a child theme, remove the filter and add your own
 * function tied to the get_the_excerpt filter hook.
 *
 * @since Twenty Ten 1.0
 * @return string Excerpt with a pretty "Continue Reading" link
 */
function twentyten_custom_excerpt_more($output) {
    if (has_excerpt() && !is_attachment()) {
        $output .= twentyten_continue_reading_link();
    }
    return $output;
}

add_filter('get_the_excerpt', 'twentyten_custom_excerpt_more');

/**
 * Remove inline styles printed when the gallery shortcode is used.
 *
 * Galleries are styled by the theme in Twenty Ten's style.css.
 *
 * @since Twenty Ten 1.0
 * @return string The gallery style filter, with the styles themselves removed.
 */
function twentyten_remove_gallery_css($css) {
    return preg_replace("#<style type='text/css'>(.*?)</style>#s", '', $css);
}

add_filter('gallery_style', 'twentyten_remove_gallery_css');

if (!function_exists('twentyten_comment')) :

    /**
     * Template for comments and pingbacks.
     *
     * To override this walker in a child theme without modifying the comments template
     * simply create your own twentyten_comment(), and that function will be used instead.
     *
     * Used as a callback by wp_list_comments() for displaying the comments.
     *
     * @since Twenty Ten 1.0
     */
    function twentyten_comment($comment, $args, $depth) {
        $GLOBALS['comment'] = $comment;
        switch ($comment->comment_type) :
            case '' :
                ?>
                <li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
                    <div id="comment-<?php comment_ID(); ?>">
                        <div class="vcard">
                            <?php echo get_avatar($comment, 40); ?>
                        </div><!-- .vcard -->

                        <div class="comment-container">

                            <p class="comment-author muted">
                                <?php printf(__('%s <span class="says">says:</span>', 'twentyten'), sprintf('<cite class="fn">%s</cite>', get_comment_author_link())); ?>
                            </p> <!-- .comment-author -->

                            <hr />

                            <?php if ($comment->comment_approved == '0') : ?>
                                <em><?php _e('Your comment is awaiting moderation.', 'twentyten'); ?></em>
                                <br />
                            <?php endif; ?>


                            <div class="comment-body"><?php comment_text(); ?></div>

                            <p class="comment-meta commentmetadata muted"><small><a href="<?php echo esc_url(get_comment_link($comment->comment_ID)); ?>">
                                        <?php
                                        /* translators: 1: date, 2: time */
                                        printf(__('%1$s at %2$s', 'twentyten'), get_comment_date(), get_comment_time());
                                        ?></a><?php edit_comment_link(__('(Edit)', 'twentyten'), ' ');
                                        ?>
                                </small>
                            </p><!-- .comment-meta .commentmetadata -->

                            <hr />

                            <div class="reply small">
                                <?php comment_reply_link(array_merge($args, array('depth' => $depth, 'max_depth' => $args['max_depth']))); ?>
                            </div><!-- .reply -->
                        </div> <!-- .comment-container -->
                    </div><!-- #comment-##  -->

                    <?php
                    break;
                case 'pingback' :
                case 'trackback' :
                    ?>
                <li class="post pingback">
                    <p><?php _e('Pingback:', 'twentyten'); ?> <?php comment_author_link(); ?><?php edit_comment_link(__('(Edit)', 'twentyten'), ' '); ?></p>
                    <?php
                    break;
            endswitch;
        }

    endif;

    /**
     * Register widgetized areas, including two sidebars and four widget-ready columns in the footer.
     *
     * To override twentyten_widgets_init() in a child theme, remove the action hook and add your own
     * function tied to the init hook.
     *
     * @since Twenty Ten 1.0
     * @uses register_sidebar
     */
    function twentyten_widgets_init() {
        // Area 1, located at the top of the sidebar.
        register_sidebar(array(
            'name' => __('Primary Sidebar Widget Area', 'twentyten'),
            'id' => 'primary-widget-area',
            'description' => __('The first sidebar widget area (before the RSS button)', 'twentyten'),
            'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
            'after_widget' => '</li>',
            'before_title' => '<h3 class="widget-title">',
            'after_title' => '</h3>',
        ));
        register_sidebar(array(
            'name' => __('Secondary Sidebar Widget Area', 'twentyten'),
            'id' => 'secondary-widget-area',
            'description' => __('The second sidebar widget area (after the RSS button)', 'twentyten'),
            'before_widget' => '<li id="%1$s" class="widget-container %2$s">',
            'after_widget' => '</li>',
            'before_title' => '<h3 class="widget-title">',
            'after_title' => '</h3>',
        ));
    }

    /** Register sidebars by running twentyten_widgets_init() on the widgets_init hook. */
    add_action('widgets_init', 'twentyten_widgets_init');

    /**
     * Removes the default styles that are packaged with the Recent Comments widget.
     *
     * To override this in a child theme, remove the filter and optionally add your own
     * function tied to the widgets_init action hook.
     *
     * @since Twenty Ten 1.0
     */
    function twentyten_remove_recent_comments_style() {
        global $wp_widget_factory;
        remove_action('wp_head', array($wp_widget_factory->widgets['WP_Widget_Recent_Comments'], 'recent_comments_style'));
    }

    add_action('widgets_init', 'twentyten_remove_recent_comments_style');

    if (!function_exists('twentyten_posted_on')) :

        /**
         * Prints HTML with meta information for the current post—date/time and author.
         *
         * @since Twenty Ten 1.0
         */
        function twentyten_posted_on() {
            printf(__('<span class="%1$s">Posted on</span> %2$s <span class="meta-sep">by</span> %3$s', 'twentyten'), 'meta-prep meta-prep-author', sprintf('<a href="%1$s" title="%2$s" rel="bookmark"><span class="entry-date">%3$s</span></a>', get_permalink(), esc_attr(get_the_time()), get_the_date()
                    ), sprintf('<span class="author vcard"><a class="url fn n" href="%1$s" title="%2$s">%3$s</a></span>', get_author_posts_url(get_the_author_meta('ID')), sprintf(esc_attr__('View all posts by %s', 'twentyten'), get_the_author()), get_the_author()
                    )
            );
        }

    endif;

    if (!function_exists('twentyten_posted_in')) :

        /**
         * Prints HTML with meta information for the current post (category, tags and permalink).
         *
         * @since Twenty Ten 1.0
         */
        function twentyten_posted_in() {
            // Retrieves tag list of current post, separated by commas.
            $tag_list = get_the_tag_list('', ', ');
            if ($tag_list) {
                $posted_in = __('This entry was posted in %1$s and tagged %2$s. Bookmark the <a href="%3$s" title="Permalink to %4$s" rel="bookmark">permalink</a>.', 'twentyten');
            } elseif (is_object_in_taxonomy(get_post_type(), 'category')) {
                $posted_in = __('This entry was posted in %1$s. Bookmark the <a href="%3$s" title="Permalink to %4$s" rel="bookmark">permalink</a>.', 'twentyten');
            } else {
                $posted_in = __('Bookmark the <a href="%3$s" title="Permalink to %4$s" rel="bookmark">permalink</a>.', 'twentyten');
            }
            // Prints the string, replacing the placeholders.
            printf(
                    $posted_in, get_the_category_list(', '), $tag_list, get_permalink(), the_title_attribute('echo=0')
            );
        }

    endif;

    /**
     * Custom Bootstrap for Wordpress properties
     *
     */
// add theme options
    require_once ( get_stylesheet_directory() . '/theme-options.php' );

// add custom class to every image inserted into a post
    function my_image_tag_class($class) {
        $class = 'box';
        return $class;
    }

    add_filter('get_image_tag_class', 'my_image_tag_class');

// Fix for the code prettifier
    remove_filter('the_content', 'wptexturize');
    remove_filter('the_excerpt', 'wptexturize');



// Custom password protected post
    add_filter('the_password_form', 'custom_password_form');

    function custom_password_form() {
        global $post;
        $label = 'pwbox-' . ( empty($post->ID) ? rand() : $post->ID );
        $o = '<p>This post is password protected. To view it please enter your password below:</p> <form class="form-stacked protected-post-form" action="' . get_option('siteurl') . '/wp-pass.php" method="post"><fieldset>	<div class="clearfix"><label for="' . $label . '">' . __("Password:") . ' </label><div class="input"><input name="post_password" id="' . $label . '" type="password" size="30"/><input class="btn small" type="submit" name="Submit" value="' . esc_attr__("Submit") . '" /></div><!-- /clearfix -->
	</fieldset></form>
	';
        return $o;
    }

// Loads scripts
    function wpbootstrap_scripts() {
        wp_register_script('jquery-tablesorter', get_template_directory_uri() . '/js/jquery/jquery.tablesorter.min.js', array('jquery'), '2.0.5');
        wp_enqueue_script('jquery-tablesorter');

        wp_register_script('google-code-prettify', get_template_directory_uri() . '/js/google-code-prettify/prettify.js');
        wp_enqueue_script('google-code-prettify');

        wp_register_script('wpbootstrap-application', get_template_directory_uri() . '/js/application.js', array('jquery-tablesorter'));
        wp_enqueue_script('wpbootstrap-application');

        wp_register_script('wpbootstrap-form', get_template_directory_uri() . '/js/form.js', array());
        wp_enqueue_script('wpbootstrap-form');

        wp_register_script('colorbox-jquery', get_template_directory_uri() . '/js/colorbox/colorbox.js', array());
        wp_enqueue_script('colorbox-jquery');
    }

    add_action('wp_enqueue_scripts', 'wpbootstrap_scripts');
    add_theme_support('post-thumbnails');

//
    function register_my_menu() {
        register_nav_menu('footer-menu', __('footer menu'));
        register_nav_menu('header-menu', __('header menu'));
    }

    add_action('init', 'register_my_menu');


    add_action('init', 'create_service_post_type');

    function create_service_post_type() {
        register_post_type('services_available', array(
            'labels' => array(
                'name' => __('Services'),
                'singular_name' => __('Service')
            ),
            'public' => true,
            'has_archive' => true,
                )
        );
    }

    add_action('init', 'create_mapimage_post_type');

    function create_mapimage_post_type() {
        register_post_type('map_image_available', array(
            'labels' => array(
                'name' => __('Map Images'),
                'singular_name' => __('Map Image')
            ),
            'public' => true,
            'has_archive' => true,
                )
        );
    }

    //////////////////////

    add_action('init', 'codex_slider_init');

    function codex_slider_init() {
        $labels = array(
            'name' => _x('Slider Images', 'post type general name', 'your-plugin-textdomain'),
            'singular_name' => _x('Slider Image', 'post type singular name', 'your-plugin-textdomain'),
            'menu_name' => _x('Slider Images', 'admin menu', 'your-plugin-textdomain'),
            'name_admin_bar' => _x('Slider Image', 'add new on admin bar', 'your-plugin-textdomain'),
            'add_new' => _x('Add New', 'Slider Image', 'your-plugin-textdomain'),
            'add_new_item' => __('Add New Slider Image', 'your-plugin-textdomain'),
            'new_item' => __('New Slider Image', 'your-plugin-textdomain'),
            'edit_item' => __('Edit Slider Image', 'your-plugin-textdomain'),
            'view_item' => __('View Slider Image', 'your-plugin-textdomain'),
            'all_items' => __('All Images', 'your-plugin-textdomain'),
            'search_items' => __('Search Slider Image', 'your-plugin-textdomain'),
            'parent_item_colon' => __('Parent Slider Image:', 'your-plugin-textdomain'),
            'not_found' => __('No slider image found.', 'your-plugin-textdomain'),
            'not_found_in_trash' => __('No slider image found in Trash.', 'your-plugin-textdomain')
        );

        $args = array(
            'labels' => $labels,
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'query_var' => true,
            'rewrite' => array('slug' => 'book'),
            'capability_type' => 'post',
            'has_archive' => true,
            'hierarchical' => false,
            'menu_position' => null,
            'supports' => array('title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments')
        );

        register_post_type('slider', $args);
    }

    add_action('admin_menu', 'register_customer_plot_detail_grid_page');

    function register_customer_plot_detail_grid_page() {
        add_menu_page('Customer Plan List', 'Customer Plan', 'manage_options', 'cpdg', 'plot_detail_grid_html');
    }

    function plot_detail_grid_html() {

        if (!isset($_GET['action'])) {
            include_once 'admin/customer-plot-detail-grid.php';
        } else if ($_GET['action'] == 'detail') {
            include_once 'admin/customer-plot-detail.php';
        } else if ($_GET['action'] == 'delete') {
            include_once 'admin/customer-plot-detail-delete.php';
        }
    }

    function add_admin_bootstrap_style() {
        if (isset($_GET['page']) && ($_GET['page'] == 'cpdg' || $_GET['page'] == 'pdg')) {
            wp_register_style('bootstrap', get_template_directory_uri() . '/css/bootstrap.css', array(), '');
            wp_enqueue_style('bootstrap');
        }
    }

    add_action('admin_enqueue_scripts', 'add_admin_bootstrap_style');


    if (!function_exists('custom_login_fail')) {

        function custom_login_fail($username) {
            if (isset($_SERVER['HTTP_REFERER'])) {
                $referrer = $_SERVER['HTTP_REFERER'];
                if (!empty($referrer) && !strstr($referrer, 'wp-login') && !strstr($referrer, 'wp-admin')) {
                    if (!strstr($referrer, '?login=1')) {
                        if (!strstr($referrer, '?login=2')) {
                            wp_redirect($referrer . '?login=1');
                        } else {
                            $referrer = str_replace('?login=2', '?login=1', $referrer);
                            wp_redirect($referrer);
                        }
                    } else {
                        wp_redirect($referrer);
                    }
                    exit;
                }
            }
        }

    }
    add_action('wp_login_failed', 'custom_login_fail');

    if (!function_exists('custom_login_empty')) {

        function custom_login_empty() {
            if (isset($_SERVER['HTTP_REFERER'])) {
                $referrer = $_SERVER['HTTP_REFERER'];
                if (strstr($referrer, get_home_url()) && (isset($user) ? $user : '') == null) {
                    if (!strstr($referrer, admin_url())) {
                        if (!strstr($referrer, '?login=2')) {
                            if (!strstr($referrer, site_url('wp-login.php'))) {
                                if (!strstr($referrer, '?login=1')) {
                                    wp_redirect($referrer . '?login=2');
                                } else {
                                    $referrer = str_replace('?login=1', '?login=2', $referrer);
                                    wp_redirect($referrer);
                                }
                            }
                        } else {
                            wp_redirect($referrer);
                        }
                    }
                }
            }
        }

    }
    add_action('authenticate', 'custom_login_empty');


    add_action('admin_menu', 'register_partner_detail_grid_page');

    function register_partner_detail_grid_page() {
        add_menu_page('Partner Basic Detail', 'Partner Detail', 'manage_options', 'pdg', 'partner_detail_grid_html');
    }

    function partner_detail_grid_html() {

        if (!isset($_GET['action'])) {
            include_once 'admin/partner-detail-grid.php';
        } else if ($_GET['action'] == 'detail') {
            include_once 'admin/partner-detail.php';
        }
    }

//    add_filter('body_class', 'my_class_names');
//
//    function my_class_names($classes) {
//        if (( is_user_logged_in())) {
//            $classes[] = 'logged-in';
//        }
//        return $classes;
//    }

    function get_mime_file_extension($file_ext) {
        $mimes = wp_get_mime_types();
        foreach ($mimes as $type => $mime) {
            if (strpos($type, $file_ext) !== false) {
                return wp_mime_type_icon($mime);
            }
        }
    }

    add_filter('show_admin_bar', '__return_false');
    add_action('show_user_profile', 'yoursite_extra_user_profile_fields');
    add_action('edit_user_profile', 'yoursite_extra_user_profile_fields');

    function yoursite_extra_user_profile_fields($user) {
        ?>
        <h3><?php _e("Extra profile information", "blank"); ?></h3>
        <table class="form-table">
            <tr>
                <th><label for="mobileno"><?php _e("Mobile No."); ?></label></th>
                <td>
                    <input type="text" name="mobileno" id="mobileno" class="regular-text" 
                           value="<?php echo esc_attr(get_the_author_meta('mobileno', $user->ID)); ?>" /><br />
                     <?php if ($_GET['failed'] == 'true') { ?> <p class="form-submit-error" style="color: red">This Mobile Number is already exist</p><?php }?>
                </td>
            </tr>
        </table>
        <?php
    }

    add_action('personal_options_update', 'yoursite_save_extra_user_profile_fields');
    add_action('edit_user_profile_update', 'yoursite_save_extra_user_profile_fields');

    function yoursite_save_extra_user_profile_fields($user_id) {
        global $wpdb;
        $saved = false;
        if (current_user_can('edit_user', $user_id)) {
            $query = "SELECT meta_value FROM $wpdb->usermeta WHERE meta_key='mobileno' and user_id!=$user_id";
            $rows = $wpdb->get_results($query);
            foreach ($rows as $mob) {
                $mobileArray[] = $mob->meta_value;
            }
            if (in_array($_POST['mobileno'], $mobileArray)) {
                wp_redirect(add_query_arg('failed', 'true', get_edit_user_link($user_id)));
                die();
            } else {
                update_user_meta($user_id, 'mobileno', $_POST['mobileno']);
                $saved = true;
            }
            return true;
        }
    }

    function wpdocs_selectively_enqueue_admin_script() {
        wp_enqueue_script('my_custom_script', get_template_directory_uri() . '/js/validate.js', array('jquery'), '1.0');
    }

    add_action('admin_enqueue_scripts', 'wpdocs_selectively_enqueue_admin_script');
